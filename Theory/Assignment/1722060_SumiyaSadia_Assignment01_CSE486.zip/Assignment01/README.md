# Assignment 01, CSE 486, Spring, 2021
**Sumiya Sadia(1722060042)**
**29/07/2021**

This assignment required us to create multiple activities for setting up a user profile for our project.
In my project, I have created 5 activities 

-  Main Activity
-  University Affiliation
-  Student Information
-  Second Activity
-  Final Activity

I have created three activities where users can input their information and see their inputed values. 

The Main activity has four fields that ask user's to fill in their Name, Date of Birth, National ID number, and their Blood group. A next button takes the user to another activity where the previously inputed information are shown first and then the user needs to fill in some more information about their University affiliations. The thirst activity shows all of the user information in a categorial manner.

While showing the users' information the output shows the last intent's  extra message in all fields. This is a bug to my code, and I have not found a solution for fixing it yet.

There is two more activities left to still work on. The "Second Activity" withh show previous informations as well as take the user's Email address, and Phone number as input. The "Final Activity" will finally output all information about the user.
